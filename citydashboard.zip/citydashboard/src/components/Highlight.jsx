import React,{useState} from 'react'

const arrayvalue = ["Sun","Mon","Tue","Wed","Thurs","Fri","Sat"];

function Highlight({ weatherData }) {
  return (
    <>
    <div className="color1 m-3 mt-4 p-5 contain-main" >
                                <h1 className="main-heading">Today's Highlights</h1>
                                <div className="col-lg contain-main-child">
                                    <div className="flex justify-content1 contain-item color2">
                                        <div className="contain-item-child">
                                            <img src="/src/assets/images/sun.png" alt="abc" />
                                        </div>
                                        <div className="contain-item-child">
                                            <h1>Sunrise</h1>
                                            <h2 id="sunrise">{weatherData.forecast?.forecastday[0].astro.sunrise}</h2>
                                        </div>
                                        <div className="contain-item-child">
                                            <img src="/src/assets/images/moon.png" alt="abc" />
                                        </div>
                                        <div className="contain-item-child">
                                            <h1>Sunset</h1>
                                            <h2 id="sunset">{weatherData.forecast?.forecastday[0].astro.sunset}</h2>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-lg contain-main-child">
                                    <div className="flex justify-content1 contain-item color2">
                                        <div className="contain-item-child">
                                            <img src="/src/assets/images/humidity.png" alt="abc" />
                                        </div>
                                        <div className="contain-item-child">
                                            <h1>Humidity</h1>
                                            <h2 id="humidity">{weatherData.current?.humidity}%</h2>
                                        </div>
                                        <div className="contain-item-child">
                                            <img src="/src/assets/images/pressure.png" alt="abc" />
                                        </div>
                                        <div className="contain-item-child">
                                            <h1>Pressure</h1>
                                            <h2 id="pressure">{weatherData.current?.pressure_mb} hPa</h2>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-lg contain-main-child">
                                    <div className="flex justify-content1 contain-item color2">
                                        <div className="contain-item-child">
                                            <img src="/src/assets/images/eye.png" alt="abc" />
                                        </div>
                                        <div className="contain-item-child">
                                            <h1>Visibility</h1>
                                            <h2 id="visibility">{weatherData.current?.vis_km} KM</h2>
                                        </div>
                                        <div className="contain-item-child">
                                            <img src="/src/assets/images/thermometer.png" alt="abc" />
                                        </div>
                                        <div className="contain-item-child">
                                            <h1>Feel's Like</h1>
                                            <h2 id="feel">{weatherData.current?.feelslike_c}°c</h2>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-lg contain-main-child">
                                    <div className="flex justify-content1 color2 contain-item">
                                        <div className="contain-item-child">
                                            <img src="/src/assets/images/wind.png" alt="abc" />
                                        </div>
                                        <div className="contain-item-child">
                                            <h1>Speed</h1>
                                            <h2 id="speed">{weatherData.current?.wind_kph} Km/hr</h2>
                                        </div>
                                        <div className="contain-item-child">
                                            <img src="/src/assets/images/gust.png"  alt="abc"/>
                                        </div>
                                        <div className="contain-item-child">
                                     
                                            <h1>gust</h1>
                                            <h2 id="gust">{weatherData.current?.gust_kph} Km/hr</h2>
                                        </div>
                                    </div>
                                </div>
                        </div>
      
    </>
  )
}

export default Highlight
