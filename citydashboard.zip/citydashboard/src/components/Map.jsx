// Map.jsx
// import React, { useState, useEffect } from 'react';
// import 'leaflet/dist/leaflet.css';
// import 'leaflet-control-geocoder/dist/Control.Geocoder.css';
// import L from 'leaflet';
// import 'leaflet-control-geocoder';

// const Map = () => {
//     const [location, setLocation] = useState('');
//     const [latitude, setLatitude] = useState('');
//     const [longitude, setLongitude] = useState('');

//     useEffect(() => {
//         const map = L.map('map').setView([51.505, -0.09], 13);
//         L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
//             attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
//         }).addTo(map);

//         const geocoder = L.Control.geocoder({
//             placeholder: 'Search for a location...',
//             defaultMarkGeocode: false
//         })
//         .on('markgeocode', function(e) {
//             const result = e.geocode || e.originalEvent.geocode;
//             setLocation(result.name);
//             setLatitude(result.center.lat);
//             setLongitude(result.center.lng);
//             map.setView(result.center, 15);
//         })
//         .addTo(map);

//         return () => {
//             map.remove();
//         };
//     }, []);

//     return (
//         <div>
//             <div id="map" className="map-container"></div>
//             <div className="lcontainer">

//             <p>Location: {location}</p>
//             <p>Latitude: {latitude}</p>
//             <p>Longitude: {longitude}</p>
//             </div>
//         </div>
//     );
// };

// export default Map;
