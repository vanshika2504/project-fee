import React,{useState} from 'react'
import { Link } from 'react-router-dom';

function Header({ onSearch, loading}) {

    const [searchQuery, setSearchQuery] = useState('');

    const handleSearch = () => {
        if (searchQuery.trim() !== '') {
            
            onSearch(searchQuery.trim());

            setSearchQuery('');
        }
    };  
    const handleEnterKeyPress = (e) => {
        if (e.key === "Enter") {
            handleSearch();
        }
    };

  return (
    <>
    <div className="header box">
            <div className="row">
                <div className="col-lg-4 Logo">
                    <div className="logocontain flex justify-content pr-5">
                        <img className="logo" src="/src/assets/images/logo.png" width="250" height="70"  alt="abc" />
                        <button  className="user-2-hidden" id="pagelogin"><i className="fa-solid fa-user"></i></button>
                    </div>
                </div>
                <div className="search col-lg-4 flex">
  <input
    id="searchbar"
    value={searchQuery}
    onChange={(e) => setSearchQuery(e.target.value)}
    onKeyPress={handleEnterKeyPress}
    type="text"
    name="search"
    className="search-item"
    placeholder="Enter the City....."
    style={{ width: '5550px'  }} // Adjust the width as needed
  />
  <button
    id="searchbtn"
    onClick={handleSearch}
    className="search"
  >
    <i className="fa-solid fa-magnifying-glass"></i>
  </button>
</div>
                <div className="col-lg-4 login p-5 flex">
                    <div className="loginuser">
                        <Link to="/login" >
                        <button  id="pagelogin"><i className="fa-solid fa-user" ></i>&nbsp;&nbsp;<span id="logindata">Login</span></button>
                        </Link>
                    </div>
                </div>
                
            </div>
        </div>
        {loading && (
        <div id="target">
            <i className="fa-solid fa-earth-americas"></i>
        </div>
          )}
        <h1 id="error-content"><i>
            Please Enter Valid City.<br /> 
            Search Again!!</i>
        </h1>
      
    </>
  )
}

export default Header
