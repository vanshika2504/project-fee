import React, { useState } from 'react';
import { Link } from 'react-router-dom';

function Login() {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isSignUp, setIsSignUp] = useState(false);
  const [showUsernameField, setShowUsernameField] = useState(true);

  const handleSignUp = (e) => {
    e.preventDefault();
    // Implement sign up logic
    sessionStorage.setItem('name', username);
    sessionStorage.setItem('email', email);
    sessionStorage.setItem('pass', password);
    // Reset form fields
    setUsername('');
    setEmail('');
    setPassword('');
  };

  const handleSignIn = (e) => {
    e.preventDefault();
    // Implement sign in logic
  };

  const handleForgotPassword = () => {
    // Toggle visibility of the username field
    setShowUsernameField(!showUsernameField);
  };

  return (
    <div className="container">
      <button className="close">
        <Link to="/">
          <i className="fa-solid fa-arrow-left-long"></i>
        </Link>
      </button>
      <div className="form-box">
        <h1 id="title">{isSignUp ? 'Sign Up' : 'Sign In'}</h1>
        <form onSubmit={isSignUp ? handleSignUp : handleSignIn}>
          <div className="input-group">
            
              <div className="input-field flex" id="field">
                <i className="fa-solid fa-user"></i>
                <input
                  id="name"
                  type="text"
                  placeholder="Email"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  required
                  className='loginin'
                />
              </div>
            
            {isSignUp && (
              <div className="input-field flex">
                <i className="fa-solid fa-envelope"></i>
                <input
                  id="email"
                  type="email"
                  placeholder="Email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className='loginin'
                />
              </div>
            )}
            {showUsernameField && (
            <div className="input-field flex" id="field1">
              <i className="fa-solid fa-lock"></i>
              <input
                id="password"
                className='loginin'
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>
            )}
            <p id="lostpassword" onClick={handleForgotPassword}>
              <strong>Lost Password</strong> <a href="#">Click Here!</a>
            </p>
          </div>
          <div className="btn-field">
            <button type="submit" id="signup" className={!isSignUp ? 'disabled' : ''}>
              Sign Up
            </button>
            <button type="button" id="signin" className={isSignUp ? 'disabled' : ''} onClick={() => setIsSignUp(false)}>
              Sign In
            </button>
            <button type="button" id="back" className="disabled" onClick={() => setIsSignUp(false)}>
              Go Back
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default Login;

